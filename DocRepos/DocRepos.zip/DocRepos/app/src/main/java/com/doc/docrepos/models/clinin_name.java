package com.doc.docrepos.models;

public class clinin_name {
    public clinin_name(String cmname) {
        this.cmname = cmname;
    }

    public clinin_name() {
    }

    public String getCmname() {
        return cmname;
    }

    public void setCmname(String cmname) {
        this.cmname = cmname;
    }

    public String cmname;
}
