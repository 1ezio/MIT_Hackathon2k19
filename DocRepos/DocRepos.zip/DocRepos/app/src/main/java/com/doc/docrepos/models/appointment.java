package com.doc.docrepos.models;

public class appointment {
    private String appointments;

    public String getAppointments() {
        return appointments;
    }

    public void setAppointments(String appointments) {
        this.appointments = appointments;
    }

    public appointment(String appointments) {
        this.appointments = appointments;
    }

    public appointment() {
    }
}
